import json
import argparse
from .parser import fn_json_parser, call_test_json_parser
from .engine import constrained_json_generator, build_system_context
from .tokenizer import CustomTokenizer
from llm_sdk.llm_sdk import Small_LLM_Model
from pathlib import Path
import time


def argument_parser() -> argparse.Namespace:
    """
    Parse command-line arguments for the function calling pipeline.

    Returns:
        argparse.Namespace: An object containing the paths for the function
        definitions, input prompts, and output results file.
    """
    parser = argparse.ArgumentParser(
        description="Call Me Maybe - Function Calling Pipeline",
        usage="uv run python -m src [--functions_definition " +
        "<function_definition_file>] [--input <input_file>]" +
        "[--output <output_file>]"
    )
    parser.add_argument(
        "--functions_definition",
        type=str,
        default="data/input/functions_definition.json",
        help="Path to the functions definition JSON file"
    )
    parser.add_argument(
        "--input",
        type=str,
        default="data/input/function_calling_tests.json",
        help="Path for the input prompts JSON file"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="data/output/function_calling_results.json",
        help="Path to the output results JSON file"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="Qwen/Qwen3-0.6B"
    )
    return parser.parse_args()


def main() -> None:
    """
    Execute the core pipeline workflow.
    It loads the parsed arguments,
    extracts the function schemas and user prompts,
    runs the constrained JSON generator iteratively
    for each prompt, and writes
    the aggregated results into the designated output JSON file.
    """
    args = argument_parser()
    print("=== Arguments Validation ===")
    print(f"Functions file: {args.functions_definition}")
    print(f"Prompts file  : {args.input}")
    print("=" * 100)
    fn_list = fn_json_parser(args.functions_definition)
    prompts = call_test_json_parser(args.input)
    model = Small_LLM_Model(model_name=args.model)
    vocab_path = model.get_path_to_vocab_file()
    tokenizer = CustomTokenizer(vocab_path)
    results = []
    fn_tokens = [tokenizer.encode(f.name) for f in fn_list]
    system_context = build_system_context(fn_list)
    print("[\n", end="", flush=True)
    for i, p in enumerate(prompts):
        start = time.perf_counter()
        json_object = constrained_json_generator(
            model, p, fn_list, system_context, fn_tokens, tokenizer)
        results.append(json.loads(json_object))
        end = time.perf_counter()
        print(f"\nSpeed: {round((end - start), 2)} seconds")
        if i != len(prompts) - 1:
            print(",")
    print("]\n", end="", flush=True)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(results, f, indent=4)


if __name__ == "__main__":
    try:
        start = time.perf_counter()
        main()
        end = time.perf_counter()
        print(f"Speed: {round((end - start) / 60, 2)} minutes")
    except KeyboardInterrupt as e:
        print(e)
    except Exception as e:
        print(e)
