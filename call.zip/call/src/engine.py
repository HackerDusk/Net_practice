import sys
import re
from llm_sdk.llm_sdk import Small_LLM_Model
from .models import Funct
from .tokenizer import CustomTokenizer
import json
try:
    import numpy as np
except ModuleNotFoundError:
    print("Error: try uv add numpy", file=sys.stderr)
    sys.exit(1)


def build_system_context(allowed_functions: list[Funct]) -> str:
    """
    Constructs a comprehensive system context string for the LLM,
    detailing the available functions, their descriptions, parameters,
    and illustrative examples.
    This context is crucial for guiding the LLM in generating accurate
    and syntactically valid function call JSON structures
    based on user prompts.
    """
    system_context = 'You are a helpful assistant that maps user prompts to'
    system_context += ' precise function calls.\n'
    system_context += 'Available functions:\n'
    for f in allowed_functions:
        system_context += (f"- {f.name}: " +
                           f"{f.description}. Parameters: " +
                           f"{list(f.parameters.keys())}\n")
    system_context += '\nEXAMPLES:\n'
    system_context += (
        "User: Read the file at " +
        "/var/data/config.json with utf-8\n"
    )
    system_context += (
        'AI: {\n  "prompt": "Read the file at ' +
        '"/var/data/config.json with utf-8",\n  "name": "fn_read_file",\n  ' +
        '"parameters": {\n    "path": "/var/data/config.json",\n    ' +
        '"encoding": "utf-8"\n  }\n}\n'
    )
    system_context += 'User: Format template: Say "hello" to {name}\n'
    system_context += (
        'AI: {\n  "prompt": "Format template: Say \\"hello\\" ' +
        'to {name}",\n  "name": "fn_format_template",\n  "parameters": {\n' +
        '    "template": "Say \\"hello\\" to {name}"\n  }\n}\n')

    system_context += 'User: Format template: Hello {user}\'s profile!\n'
    system_context += ('AI: {\n  "prompt": "Format template:' +
                       ' Hello {user}\'s profile!",\n  "name":' +
                       ' "fn_format_template",\n' +
                       '  "parameters": {\n    "template":' +
                       ' "Hello {user}\'s profile!"\n  }\n}\n')
    system_context += ('User: Read C:\\\\Users\\\\john\\\\' +
                       'config.ini with latin-1 encoding\n')
    system_context += ('AI: {\n  "prompt": "Read' +
                       ' C:\\\\Users\\\\john\\\\config.ini with' +
                       ' latin-1 encoding",\n' +
                       '  "name": "fn_read_file",\n  "parameters": {\n' +
                       '    "path": "C:\\\\Users\\\\john\\\\config.ini",\n' +
                       '    "encoding": "latin-1"\n  }\n}\n')
    return system_context


def constrained_json_generator(
    model: Small_LLM_Model,
    prompt: str,
    allowed_functions: list[Funct],
    system_context: str,
    fn_tokens: list[list[int]],
    tokenizer: CustomTokenizer
        ) -> str:
    """
    Generates structured JSON using token-level constrained decoding.
    This implementation utilizes dynamic logit masking based on the
    foundational framework by Willard & Louf (2023) to guarantee
    syntax validity.
    """
    escaped_prompt = json.dumps(prompt)[1:-1]
    prefix = '{\n  "prompt": "' + escaped_prompt + '",\n  "name": "'
    print(prefix, end="", flush=True)
    context_ids = tokenizer.encode(system_context + prefix)
    alw_names_tok = [tok[:] for tok in fn_tokens]
    max_steps = max(len(f) for f in alw_names_tok)
    all_h_score = 0.0
    for step in range(max_steps):
        next_token = list(set(
            f_tok[step] for f_tok in alw_names_tok if step < len(f_tok)))
        if not next_token:
            break
        logits = model.get_logits_from_input_ids(context_ids)
        hack_log = np.full(len(logits), -1e9)
        for tok in next_token:
            hack_log[tok] = 0.0
        new_log = logits + hack_log
        all_h_score += float(np.max(new_log))
        h_score = int(np.argmax(new_log))
        context_ids.append(h_score)
        alw_names_tok = [
            f for f in alw_names_tok if step < len(f) and f[step] == h_score]
        max_steps = max(len(f) for f in alw_names_tok)
        h_score_str = tokenizer.decode([h_score])
        prefix += h_score_str
        print(h_score_str, end="", flush=True)
    f_chosen_name = prefix.split('"name": "')[-1].split('"')[0]
    chosen_funct = next((
        f for f in allowed_functions if f.name == f_chosen_name), None)
    prefix += '",\n  "parameters": {\n'
    print('",\n  "parameters": {\n', end="", flush=True)
    if chosen_funct and chosen_funct.parameters:
        params_dict = chosen_funct.parameters
        param_keys = list(params_dict.keys())
        negatives = []
        for idx_k, k in enumerate(param_keys):
            v = params_dict[k]
            p_type = v.type if hasattr(v, "type") else "string"
            prefix += f'    "{k}": '
            print(f'    "{k}": ', end="", flush=True)
            if p_type in ("string", "str"):
                prefix += '"'
                print('"', end="", flush=True)
                context_ids = tokenizer.encode(system_context + prefix)
                first_token = True
                while True:
                    logits = model.get_logits_from_input_ids(context_ids)
                    tok = int(np.argmax(logits))
                    token_str = tokenizer.decode([tok])
                    if first_token and ('/' + token_str) in prompt:
                        prefix += '/'
                        print('/', end="", flush=True)
                        context_ids = tokenizer.encode(
                            system_context + prefix)
                        first_token = False
                        continue
                    if (
                        first_token and
                        token_str.startswith(' ') and not
                        token_str.startswith(' /') and not
                            token_str.startswith(' \\')):
                        token_str = token_str[1:]
                    first_token = False
                    closing_quote_idx = -1
                    is_escaped = False
                    for idx, char in enumerate(token_str):
                        if char == '"' and not is_escaped:
                            closing_quote_idx = idx
                            break
                        if char == '\\':
                            is_escaped = not is_escaped
                        else:
                            is_escaped = False
                    if closing_quote_idx != -1:
                        prefix += token_str[:closing_quote_idx]
                        print(
                            token_str[:closing_quote_idx], end="", flush=True)
                        break
                    prefix += token_str
                    print(token_str, end="", flush=True)
                    context_ids = tokenizer.encode(
                        system_context + prefix)
                prefix += '"'
                print('"', end="", flush=True)
            elif p_type in ("number", "integer", "int", "float", "double"):
                value_str = ""
                context_ids = tokenizer.encode(system_context + prefix)
                while True:
                    logits = model.get_logits_from_input_ids(context_ids)
                    tok = int(np.argmax(logits))
                    token_str = tokenizer.decode([tok])
                    numeric_part = ""
                    has_delimiter = False
                    for char in token_str:
                        if char in "0123456789.-":
                            numeric_part += char
                        elif char in [',', '}', ' ', '\n']:
                            has_delimiter = True
                            break
                    value_str += numeric_part
                    if has_delimiter:
                        break
                    context_ids = tokenizer.encode(
                        system_context + prefix + value_str)
                if p_type not in ("integer", "int"):
                    if not value_str or value_str == "-":
                        value_str = "0.0"
                    if "." not in value_str:
                        value_str += ".0"
                else:
                    if not value_str or value_str == "-":
                        value_str = "0"
                p_sp = []
                for sp in prompt.split():
                    match = re.search(r"-\d+", sp)
                    if match:
                        clean_n = match.group()
                        p_sp.append(float(clean_n))
                if p_type not in ("integer", "int"):
                    val = float(value_str)
                    neg_val = -val
                    if any(
                        n for n in p_sp
                            if neg_val == n and n not in negatives):
                        value_str = '-' + value_str
                        negatives.append(neg_val)
                else:
                    val = int(value_str)
                    neg_val = -val
                    if any(
                        n for n in p_sp
                            if neg_val == n and n not in negatives):
                        value_str = '-' + value_str
                        negatives.append(neg_val)
                prefix += value_str
                print(value_str, end="", flush=True)
            elif p_type in ("boolean", "bool"):
                bool_str = ""
                context_ids = tokenizer.encode(system_context + prefix)
                while True:
                    logits = model.get_logits_from_input_ids(context_ids)
                    tok = int(np.argmax(logits))
                    token_str = tokenizer.decode([tok])
                    bool_str += token_str
                    clean_check = bool_str.lower().strip()
                    if "true" in clean_check or "false" in clean_check:
                        break
                    if not bool_str:
                        bool_str = "false"
                    context_ids = tokenizer.encode(
                        system_context + prefix + bool_str)
                bool_prefix = "true" if "true" in bool_str else "false"
                prefix += bool_prefix
                print(bool_prefix, end="", flush=True)
            else:
                prefix += '"unknown"'
                print('"unknown"', end="", flush=True)
            if idx_k < len(param_keys) - 1:
                prefix += ",\n"
                print(",\n", end="", flush=True)
    prefix += '\n  }\n}'
    print('\n  }\n}', end="", flush=True)
    print("\n\n=== GENERATION VISUALIZATION ===")
    print(f"Function : {f_chosen_name}")
    print(f"Total logits    : {all_h_score:.2f}")
    print("===============================")
    return prefix
