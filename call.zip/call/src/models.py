from typing import Dict
import sys
try:
    from pydantic import BaseModel
except ModuleNotFoundError:
    print("Error: try uv add pydantic", file=sys.stderr)
    sys.exit(1)


class ParameterDetail(BaseModel):
    """
    Represents the metadata detail of a function parameter.
    Attributes:
    type (str):
    Expected data type of the
    parameter (e.g., 'string', 'integer').
    """
    type: str


class Funct(BaseModel):
    """
    Represents the complete schema definition of a callable function.

    This model is used to structure and validate function signatures, making it
    easier for language models to map user prompts to valid programmatic calls.

    Attributes:
        name (str): The exact name of the function.
        description (str): A clear description of what
        the function does, used by the LLM for context.
        parameters (Dict[str, ParameterDetail]): A mapping of
        parameter names to their structural details.
        returns (Dict[str, str]): A dictionary describing
        the expected return value type.
    """
    name: str
    description: str
    parameters: Dict[str, ParameterDetail]
    returns: Dict[str, str]
