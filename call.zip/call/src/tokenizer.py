import json
import sys
from pathlib import Path


class CustomTokenizer:
    """
    A custom tokenizer that reimplements encode and decode from scratch
    using the model vocabulary JSON file, without relying on model.encode()
    or model.decode().

    Reads the vocab JSON via get_path_to_vocab_file() and performs greedy
    longest-match tokenization directly on the vocabulary dictionary.
    The space character is auto-detected from the vocabulary (typically 'Ġ').

    Attributes:
        vocab (dict): Mapping from token string to token ID.
        rev_vocab (dict): Reverse mapping from token ID to token string.
        space_char (str): The character used to represent a leading space.
    """
    def __init__(self, vocab_path: str | Path):
        """
        Initialize the vocabulary dictionary (text -> number)
        and create the reverse dictionary (number -> text).
        """
        self._encode_cache: dict[str, list[int]] = {}
        self._decode_cache: dict[tuple[int, ...], str] = {}
        try:
            with open(vocab_path, 'r', encoding='utf-8') as f:
                self.vocab = json.load(f)
            self.rev_vocab = {v: k for k, v in self.vocab.items()}
            self.space_char = next(
                (tok[0] for tok in self.vocab
                 if len(tok) == 2 and tok[1].isalpha()), 'Ġ'
            )
        except FileNotFoundError:
            print(f"Error: Vocabulary file not found at {vocab_path}",
                  file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Unexpected error during parsing: {e}", file=sys.stderr)
            sys.exit(1)

    def encode(self, text: str) -> list[int]:
        """
        Takes raw text and returns the list of token IDs.
        """
        text = text.replace(' ', self.space_char)
        tok_ids = []
        i = 0
        n = len(text)
        if text in self._encode_cache:
            return self._encode_cache[text]
        while i < n:
            match_found = False
            for j in range(len(text), i, -1):
                if text[i:j] in self.vocab:
                    tok_ids.append(self.vocab[text[i:j]])
                    match_found = True
                    i = j
                    break
            if not match_found:
                i += 1
        self._encode_cache[text] = tok_ids
        return tok_ids

    def decode(self, tok_ids: list[int]) -> str:
        """
        Takes a list of IDs and reconstructs the string.
        """
        key = tuple(tok_ids)
        if key in self._decode_cache:
            return self._decode_cache[key]
        text = "".join(
            [
                self.rev_vocab.get(
                    tok, "") for tok in tok_ids]).replace(
                        self.space_char, ' ')
        self._decode_cache[key] = text
        return text
