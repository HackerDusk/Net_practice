from .models import Funct
import json
import sys
try:
    from pydantic import ValidationError
except ModuleNotFoundError:
    print("Error: try uv add pydantic", file=sys.stderr)
    sys.exit(1)


def fn_json_parser(file_path: str) -> list[Funct]:
    """
    Loads the function definition JSON file securely and parse it .
    If the file does not exist or is corrupted,
    the program displays a clear message and
    shuts down cleanly without crashing (without a large traceback).
    """
    try:
        with open(file_path, 'r') as f:
            content = json.load(f)
            return [Funct(**d) for d in content]
    except FileNotFoundError:
        print("Error: Specified file not found: " +
              f"{file_path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' " +
              "is not a valid JSON.", file=sys.stderr)
        sys.exit(1)
    except ValidationError as e:
        print(f"Structure Error: {e.errors()[0]['msg']}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error during parsing: {e}", file=sys.stderr)
        sys.exit(1)


def call_test_json_parser(file_path: str) -> list[str]:
    """
    Loads the function calling tests JSON file securely and parse it .
    If the file does not exist or is corrupted,
    The program displays a clear message and
    shuts down cleanly without crashing (without a large traceback).
    """
    try:
        with open(file_path, 'r') as f:
            content = json.load(f)
            return [d['prompt'] for d in content]
    except FileNotFoundError:
        print("Error: The specified file could not " +
              f"be found: '{file_path}'", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}'" +
              " is not a valid JSON.", file=sys.stderr)
        sys.exit(1)
    except KeyError as e:
        print(f"Error: Missing key {e} in '{file_path}'", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error during parsing: {e}", file=sys.stderr)
        sys.exit(1)
