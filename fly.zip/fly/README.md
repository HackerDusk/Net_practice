*This project has been created as part of the 42 curriculum by srandro.*

# Fly-in

## Table of contents

- [Fly-in](#fly-in)
  - [Table of contents](#table-of-contents)
  - [Description](#description)
  - [Instructions](#instructions)
    - [Requirements](#requirements)
    - [Install](#install)
    - [Run](#run)
    - [Debug](#debug)
    - [Lint and type-check](#lint-and-type-check)
    - [Clean](#clean)
    - [Visual mode](#visual-mode)
  - [Resources](#resources)
    - [AI usage](#ai-usage)
    - [Peer review](#peer-review)
  - [Algorithm choices and implementation strategy](#algorithm-choices-and-implementation-strategy)
    - [Complexity](#complexity)
    - [Caching and recomputation](#caching-and-recomputation)
    - [Memory usage](#memory-usage)
    - [Scheduling strategy](#scheduling-strategy)
  - [Performance and benchmarks](#performance-and-benchmarks)
  - [Testing and robustness](#testing-and-robustness)
    - [Advanced routing behaviors \& Edge cases](#advanced-routing-behaviors--edge-cases)
  - [Visual representation](#visual-representation)
    - [Terminal mode](#terminal-mode)
    - [pygame mode](#pygame-mode)

## Description

Fly-in is a drone-fleet routing simulator. Given a map of interconnected
zones (a graph) with a unique start zone and a unique end zone, the goal
is to move a whole fleet of drones from start to end in the smallest
possible number of simulation turns, while respecting:

- zone occupancy limits (`max_drones`)
- connection (link) capacity limits (`max_link_capacity`)
- movement costs tied to zone type (`normal`: 1 turn, `restricted`:
  2 turns, `blocked`: never enterable, `priority`: 1 turn, preferred)
- simultaneous drone movement, with strategic waiting and conflict
  avoidance

The map format, zone/connection metadata, and movement rules are parsed
from a custom text format (see `maps/` for examples).

## Instructions

### Requirements
- Python 3.10+
- [uv](https://docs.astral.sh/uv/)

### Install
```
make install
```

### Run
```
make run
```
or, to run on a specific map:
```
uv run python3 main.py <path_to_map_file>
```

### Debug
```
make debug
```
Runs the program under Python's built-in debugger (`pdb`).

### Lint and type-check
```
make lint          # flake8 + mypy (project defaults)
make lint-strict    # flake8 + mypy --strict
```

### Clean
```
make clean
```
Removes `__pycache__`, `.mypy_cache`, and `.pytest_cache`.

### Visual mode

```
uv run python3 main.py <path_to_map_file> --visual text
uv run python3 main.py <path_to_map_file> --visual pygame
```

> `--visual text` is the default and prints the turn-by-turn movement
log. `--visual pygame` opens a graphical window instead (see
[Visual representation](#visual-representation) below).

## Resources

- [Dijkstra's algorithm — Wikipedia](https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm)
- [Python `typing` module documentation](https://docs.python.org/3/library/typing.html)
- [Intro to Graph theory](https://42born2code.slack.com/archives/D0BLW00F5LJ/p1785411351303249)
- [Breadth-first and depth-first graph traversal](https://youtu.be/lw_GbcA36HA?si=772Jwzk4Mpntiu3V)
- [Pygame in 18 Minutes](https://youtu.be/blLLtdv4tvo?si=-U-4g7hnWNG5x9oY)
- [pygame documentation](https://www.pygame.org/docs/)
- [Shortest Path basics](https://leetcode.com/problems/unique-paths/description/)
- [visualgo pathfinding](https://visualgo.net/en)
- [regex documentation](https://regexlearn.com/)

### AI usage

- Explaining general Python/tooling concepts used in the codebase.
- Doing deep research
- Structuring this README.



### Peer review

Some friends reviewed the project with me and specifically stress-tested
the parser by hand-corrupting a working map file (unclosed metadata
brackets, a duplicated `max_drones` key, garbage text appended after a
connection line, two zones placed at the same coordinates). That pass
caught a real regression: a metadata-bracket check that looked correct
but had been silently neutered by a one-character change (`and`
instead of `or`), so a genuinely malformed line was only reported
several lines later, on a confusing downstream symptom instead of the
actual cause. See [Testing and robustness](#testing-and-robustness)
for the full list of what we deliberately tried to break.

## Algorithm choices and implementation strategy

`path_finding` (in `algorithm.py`, class `Path_finding`) is Dijkstra's
algorithm run over an augmented state space: instead of searching over
`Zone` nodes alone, it searches over `(Zone, lap)` pairs, where `lap`
is the simulation turn. This is necessary because the same physical
zone can be free at one turn and full at another — the "cost" Dijkstra
minimizes here is literally the arrival turn.

- Waiting in place is modeled as a self-loop neighbor (a zone is added
  to its own neighbor list during the search), cost 1 — this reuses
  the same relaxation step instead of needing a separate "wait" case.
  To guarantee termination even when the goal is genuinely unreachable
  (a required zone is `blocked`, or the graph is disconnected), the
  search caps how many turns it is willing to "wait" through before
  giving up, instead of exploring an unbounded number of wait states.

- Movement cost is 2 turns into a `restricted` zone, 1 turn otherwise,
  directly implementing the subject's movement-cost rules.

- Zone and connection occupancy at a given future turn are checked
  against two shared calendars, `agenda` and `conn_agenda`, filled in
  by `book_a_spot` right after each drone's path is found.

- `priority` zones are preferred over other zones when two paths reach
  the same state at the same cost, using a secondary rank in the
  priority-queue tuple (rather than `id()` object identity, which is
  what an earlier version used and which picked a path arbitrarily
  instead of favoring `priority` zones as the subject asks).

- `id()` is still used as the final tie-breaker once cost and
  priority-rank are equal, since `Zone` objects have no natural
  ordering and `heapq` needs one to compare tuples.


### Complexity

- **`V`** = number of zones on the map.
- **`L`** = how many turns ahead a single search is willing to look.
  It's not a fixed constant — it grows automatically with how
  congested the map already is, and is capped internally so the
  search always terminates instead of running forever.
- One drone's search visits at most `V × L` states (a state = "this
  zone, at this turn"), and each state costs `O(log(V·L))` to
  push/pop from the priority queue. So finding **one** drone's path
  costs `O(V·L·log(V·L))`.
- Drones are routed one after another, not all at once (see
  [Scheduling strategy](#scheduling-strategy)). So the **whole**
  simulation, for `N` drones, costs `O(N·V·L·log(V·L))`.

### Caching and recomputation

No path is cached or memoized between drones — every drone re-runs
`path_finding` completely from scratch. What makes this correct
without caching is `agenda`/`conn_agenda`: once a drone's path is
found, `book_a_spot` records every zone and connection it will occupy
and at which turn. The next drone's fresh Dijkstra search reads those
same calendars, so it naturally routes around what earlier drones have
already reserved — no earlier drone ever needs to be re-planned.

### Memory usage

- `agenda` and `conn_agenda` each store one entry per (zone-or-
  connection, turn) that a drone actually occupies. Their combined
  size grows with the total length of every drone's path —
  `O(N·L)` in the worst case — and this is the memory that stays
  around for the whole simulation.
- Each drone's own search state (`visited`, `parents`, the priority
  queue) is bounded by `O(V·L)`, but it's temporary: it's thrown
  away as soon as that drone's path is found, before the next
  drone's search starts. It never accumulates across drones.
### Scheduling strategy

Drones are routed **sequentially** (drone 1, then drone 2, ...), each
one finding its best path *given* what earlier drones have already
booked. This is a deliberate simplification (a first-come-first-served
greedy scheduler) rather than a globally joint optimization across all
drones at once — it respects every constraint, but does not guarantee
the mathematically optimal total turn count on every topology. A
possible improvement (not implemented) would be to re-order or jointly
replan drones to reduce the total turn count further.

`fly_in` (in `main.py`, class `Simulator`) then expands each drone's
key-moment path into a full tick-by-tick timeline, filling in waits
and the intermediate "in transit on a connection" tick for
restricted-zone crossings, before printing the turn-by-turn movement
log.

## Performance and benchmarks

All turn counts below were measured by actually running each provided
map, not estimated:

| Map | Turns achieved | Subject's target |
|---|---|---|
| easy/01_linear_path | 4 | ≤ 6 |
| easy/02_simple_fork | 5 | ≤ 6 |
| easy/03_basic_capacity | 6 | ≤ 8 |
| medium/01_dead_end_trap | 8 | ≤ 15 |
| medium/02_circular_loop | 11 | ≤ 20 |
| medium/03_priority_puzzle | 7 | ≤ 12 |
| hard/01_maze_nightmare | 14 | ≤ 45 |
| hard/02_capacity_hell | 18 | ≤ 60 |
| hard/03_ultimate_challenge | 26 | ≤ 35 |
| **challenger/01_the_impossible_dream** | **43** | reference record: 45 |

Every provided map is solved comfortably under its target, and the
optional Challenger map (25 drones) beats the reference record of 45
turns. The main lever behind this is the `priority`-aware tie-break
and the shared `agenda`/`conn_agenda` calendars, which let later
drones route around congestion instead of blindly repeating the same
shortest path and queueing behind each other.

## Testing and robustness

Beyond the required flake8/mypy compliance, the parser and simulation
were deliberately tested against malformed and adversarial input,
partly by hand and partly with a friend during
[peer review](#peer-review). What is correctly rejected with a clear
error message (no crash, no silent misbehavior):

**Parsing**
- Duplicate zone names
- Multiple `start_hub` / `end_hub` zones, or either one missing
- A connection referencing a zone that was never defined
- The same connection declared twice (`a-b` and `b-a` both present)
- An invalid zone type (anything other than `normal`, `blocked`,
  `restricted`, `priority`)
- `max_drones` or `max_link_capacity` set to 0 or a negative number
- A zone line missing required fields (e.g. no coordinates)
- A metadata block with an unclosed or unmatched bracket
  (`[color=green` with no closing `]`)
- `nb_drones` not on the first line of the file
- `nb_drones` missing entirely, or set to 0
- A non-integer coordinate
- A missing map file, a directory passed instead of a file, or an
  empty file

**Simulation / algorithm**
- A `blocked` zone type is never entered — including when it is the
  `end_hub` itself, which used to be silently reachable through it
- A genuinely unreachable goal (a disconnected zone, or one only
  reachable through a `blocked` zone) is reported as an error instead
  of hanging forever
- `restricted` zones cost exactly 2 turns and cannot be paused on
  mid-connection
- `priority` zones are actually preferred over an equal-cost `normal`
  path, not chosen arbitrarily
- Two zones sharing the exact same (x, y) coordinates on the map grid.
- Malformed metadata blocks (e.g., extra characters inside brackets,
missing brackets, unassigned keys).

**Load**
- All maps in `maps/` plus the Challenger map (see table above)
- A custom 40-drone, 60-zone chained map with capacity-limited
  connections, to check the scheduler doesn't degrade badly under
  heavy congestion

### Advanced routing behaviors & Edge cases
Beyond the fundamental Dijkstra implementation, the augmented state-space and priority queue design naturally resolves several complex routing phenomena without requiring hardcoded edge-case exceptions:

- **Dynamic Queuing (Zero "Yo-Yo" Effect):** When facing severe network bottlenecks (e.g., a 1-capacity bridge), drones do not endlessly oscillate between adjacent zones in panic. By evaluating "waiting in place" as a valid self-loop edge with a specific priority (`rank = 2`), drones form logical queues at hubs until the path clears, ensuring realistic and fluid traffic.
- **Cost vs. Congestion Break-Even Analysis:** The algorithm dynamically weighs wait times against structural movement costs. If a fast `normal` path (1 turn) is heavily congested, later drones will automatically route through slower `restricted` zones (costing 2 turns) once the algorithm calculates that waiting for the fast path will ultimately take longer.
- **Capacity-Driven Emergency Fallbacks:** In extreme funnel scenarios where intermediate zones reach their strict `max_drones` limit, the algorithm guarantees physical capacity laws are never violated. If a drone cannot mathematically wait in a zone because it is full, it seamlessly computes valid fallback maneuvers (including retreating to larger capacity hubs) rather than breaking the simulation or failing to find a path.
- **Deep-Time Scaling:** The custom bounding condition (`next_lap > ...`) ensures the search does not run infinitely, but is generous enough to handle massive congestion. This extreme robustness allowed the algorithm to solve the 25-drone Challenger map (*The Impossible Dream*) in **43 turns**, successfully beating the subject's reference record of 45 turns.

**Advanced Parser Stress-Tests (Rejected cases):**
- Unclosed brackets: `start_hub: start 0 0 [color=green`
- Missing keys or values: `hub: waypoint1 1 0 [color=]`
- Extraneous garbage inside brackets: `end_hub: end 2 2 [feeffe color=green fef]`
- Missing brackets entirely: `start_hub: start 0 0 color=green`
- Inverted brackets: `hub: waypoint1 0 0 ]color=green[`
- Double brackets: `start_hub: start 0 0 [[color=green]]`
- Extraneous text outside brackets: `start_hub: start 0 0 [color=green] hello`
- Duplicate metadata keys: `start_hub: start 0 0 [color=green color=red]` or `[zone=blocked zone=priority]`
- Bad coordinates mixed with metadata: `start_hub: start invalid_x 0 [color=green]`
- Two zones declared at the exact same `(x, y)` coordinates.

**Validated Edge Cases:**
- Empty metadata blocks are perfectly legal: `start_hub: start 0 0 []`
- Unusual but legal names (as long as they don't contain spaces or dashes): `start_hub: st#art 0 0`

## Visual representation

### Terminal mode
The default mode: for each turn where at least one drone moves, a
`Total turns: N` progress line is printed to stderr, followed by the
moves themselves on stdout as space-separated `D<id>-<zone>` entries
— exactly the format the subject asks for. It's plain text with no
coloring; `--visual pygame` below is the graphical alternative.

### pygame mode
- Each zone is drawn directly as a colored octagon — no external
  image asset, no border — filled with its own `color` metadata; a
  zone with no color (or an unrecognised one) falls back to a
  neutral grey instead of raising an error.
- The simulation opens **paused** on turn 0 instead of playing
  immediately.
- Controls:
  - `SPACE` — pause / resume
  - `→` / `←` — step one turn forward / backward (pauses)
  - `R` — replay from turn 0
  - click-and-drag — pan the camera
  - `ESC` — close the window
- The window is resizable and opens close to the size of the screen;
  resizing it recomputes the whole layout so zone labels never
  overlap, however long the names are.
