"""Algorithm module for drone pathfinding."""
import heapq
from models import Zone, ZoneType


class Path_finding():
    """Contains methods that find the fastest valid route for one drone."""

    @staticmethod
    def reconstruct_path(
        parents: dict[tuple[Zone, int], tuple[Zone, int]],
        start: tuple[Zone, int],
            goal: tuple[Zone, int]) -> list[tuple[Zone, int]] | None:
        """Walk the parent chain from goal back to start and reverse it.

        Args:
            parents: Maps each visited (zone, lap) state to the state it
                was reached from.
            start: The (zone, lap) state the search began at.
            goal: The (zone, lap) state the search ended at.

        Returns:
            The ordered list of (zone, lap) states from start to goal.
        """
        curr_node: tuple[Zone, int] = goal
        path: list[tuple[Zone, int]] = [goal]
        while curr_node != start:
            curr_node = parents[curr_node]
            path.append(curr_node)
        return path[::-1]

    def path_finding(
        self,
        zones: dict[str, Zone],
        agenda: dict[tuple[str, int], list[int]],
        conn_agenda: dict[tuple[str, str, int], list[int]]) -> (
            list[tuple[Zone, int]] | None):
        """Find the fastest valid route for one drone.

        Runs Dijkstra's algorithm over an augmented state space of
        (Zone, simulation lap) pairs, so zone/connection capacity and
        per-turn occupancy (from `agenda` / `conn_agenda`) are respected.

        Args:
            zones: All zones on the map, indexed by name.
            agenda: Zone occupancy already booked by earlier drones, as
                {(zone_name, lap): [drone_id, ...]}.
            conn_agenda: Connection usage already booked by earlier drones,
                as {(zone_name_a, zone_name_b, lap): [drone_id, ...]}.

        Returns:
            The path as a list of (Zone, lap) states from start to end,
            or None if no valid path exists given current bookings.
        """
        queue: list[tuple[int, int, int, Zone]] = []
        visited: set[tuple[Zone, int]] = set()
        parents: dict[tuple[Zone, int], tuple[Zone, int]] = {}
        start: Zone | None = next((
            z for z in zones.values() if z.role == "start_hub"), None)
        goal: Zone | None = next(
            (z for z in zones.values() if z.role == "end_hub"), None)
        if not start or not goal:
            raise ValueError("Error: No start_hub or no end_hub")
        heapq.heappush(queue, (0, 1, id(start), start))
        visited.add((start, 0))
        while queue:
            curr_lap, _, _, curr_hub = heapq.heappop(queue)
            if curr_hub.role == "end_hub":
                return self.reconstruct_path(
                    parents, (start, 0), (goal, curr_lap))
            for nb in curr_hub.get_neighbors() + [curr_hub]:
                cost = 1
                if curr_hub != nb:
                    if nb.zone_type == ZoneType.RESTRICTED:
                        cost = 2
                next_lap = curr_lap + cost
                if next_lap > len(zones) * 4 + max(
                        (lap for (_, lap) in agenda), default=0):
                    continue
                drones_in_next_zone = len(agenda.get((nb.name, next_lap), []))
                drone_in_conn: int = 0
                max_link_cap: float = float("inf")
                if curr_hub != nb:
                    zone1, zone2 = sorted([curr_hub.name, nb.name])
                    for conn in curr_hub.connections:
                        if conn.zone_a == nb or conn.zone_b == nb:
                            max_link_cap = conn.max_link_capacity
                            break
                    drone_in_conn = len(
                        conn_agenda.get((zone1, zone2, curr_lap), []))
                zone_has_room = (
                    nb.role in (
                        "start_hub", "end_hub") or (
                            drones_in_next_zone) < nb.max_drones)
                if (
                        zone_has_room and drone_in_conn < max_link_cap):
                    not_blocked = nb.zone_type != ZoneType.BLOCKED
                    not_seen = (nb, next_lap) not in visited
                    if not_blocked and not_seen:
                        parent_entry = parents.get((curr_hub, curr_lap))
                        prev_zone = parent_entry[0] if parent_entry else None
                        if nb.zone_type == ZoneType.PRIORITY:
                            rank = 0
                        elif curr_hub != nb and (
                                nb.role == "start_hub" or nb == prev_zone):
                            rank = 3
                        elif nb == curr_hub:
                            rank = 2
                        else:
                            rank = 1
                        heapq.heappush(queue, (next_lap, rank, id(nb), nb))
                        visited.add((nb, next_lap))
                        parents[(nb, next_lap)] = (curr_hub, curr_lap)
        return None
