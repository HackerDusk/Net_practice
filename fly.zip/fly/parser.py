"""Parsing utilities for map files."""
import sys
import re
from typing import Dict, Tuple, Optional
from models import Zone, Connection, ZoneType


class Parser():
    """Parses a full map file into its zones and drone count."""

    @staticmethod
    def parse_metadata(
        metadata_str: str,
        line_num: int,
            line: str) -> Dict[str, str]:
        """Parse a bracketed metadata block into a key/value dictionary.

        Args:
            metadata_str: The raw "[key=value key2=value2]" text.

        Returns:
            A dict mapping each lowercase key to its lowercase value.
        """
        zone_key: list[str] = [
            "color",
            "max_drones",
            "zone"
        ]
        is_conn: bool = line.startswith(("start_hub", "hub", "end_hub"))
        m_data: Dict[str, str] = {}
        strict_metadata = (
            r'^\[[ \t]*([a-zA-Z_]+[ \t]*=[ \t]*[a-zA-Z0-9_]+[ \t]*'
            r'([ \t]+[a-zA-Z_]+[ \t]*=[ \t]*[a-zA-Z0-9_]+[ \t]*)*)\]$')
        if not re.fullmatch(strict_metadata, metadata_str):
            print(f"Error line {line_num}: Invalid"
                  " metadata format.", file=sys.stderr)
            sys.exit(1)
        clean_str = metadata_str.strip().replace("[", "").replace("]", "")
        pairs = re.findall(
            r'([a-zA-Z_]+)[ \t]*=[ \t]*([a-zA-Z0-9_]+)',
            clean_str)
        for k, v in pairs:
            k_clean = k.lower()
            if is_conn and k_clean not in zone_key:
                print(f"Error line {line_num}: {k!r} not in"
                      " metadata key", file=sys.stderr)
                sys.exit(1)
            if not is_conn and k_clean != "max_link_capacity":
                print(f"Error line {line_num}: Wrong metadata key"
                      f" {k_clean!r} in"
                      f" {metadata_str!r}", file=sys.stderr)
                sys.exit(1)
            m_data[k_clean] = v.lower()
        return m_data

    def parse_zone_line(
        self,
        line: str,
        role: str,
            line_num: int) -> Optional[Zone]:
        """Parse a single 'start_hub:' / 'end_hub:' / 'hub:' line into a Zone.

        Args:
            line: The raw line, already lowercased.
            May still contain its bracketed metadata block, if any — this
            method locates and strips it.
            role: The zone's role, taken from the line prefix.

        Returns:
            The parsed Zone, or None if the line doesn't carry enough fields.
        """
        try:
            m_data: Dict[str, str] = {}
            if "[" in line or "]" in line:
                if "[" not in line or "]" not in line:
                    print(f"Error line {line_num}: malformed metadata block in"
                          f" '{line.strip()}'", file=sys.stderr)
                    sys.exit(1)
                start_idx = line.find("[")
                end_idx = line.find("]")
                if start_idx > end_idx:
                    print(f"Error line {line_num}: inverted"
                          " metadata brackets in"
                          f" '{line.strip()}'", file=sys.stderr)
                    sys.exit(1)
                if line[start_idx - 1] in (' ', '\t'):
                    m_data = self.parse_metadata(
                        line[start_idx:end_idx + 1].strip(), line_num, line)
                else:
                    print(f"Error line {line_num}:"
                          " Ivalid metadata", file=sys.stderr)
                    sys.exit(1)
                line = line[:start_idx] + line[end_idx + 1:]
            content = line.split(":", 1)[1].strip()
            parts = content.split()
            if len(parts) != 3:
                print(f"Error line {line_num}: zone line"
                      " missing required fields (name x y):"
                      f" {line.strip()!r}", file=sys.stderr)
                sys.exit(1)
            name = parts[0]
            if "-" in name or " " in name:
                print(f"Error line {line_num}: Invalid zone name {name!r}"
                      " (dash and space forbidden)",
                      file=sys.stderr)
                sys.exit(1)
            x = int(parts[1])
            y = int(parts[2])
            z_type_str = m_data.get("zone", "normal").lower()
            if z_type_str not in [t.value for t in ZoneType]:
                print(f"Error line {line_num}: Invalid zone"
                      f" type {z_type_str!r}", file=sys.stderr)
                sys.exit(1)
            zone_type = ZoneType(z_type_str)
            color = m_data.get("color", "none").lower()
            try:
                if role in ["start_hub", "end_hub"]:
                    max_drones = float("inf")
                else:
                    max_drones = int(m_data.get("max_drones", 1))
                if max_drones <= 0:
                    print(f"Error line {line_num}: max drones must"
                          " be a positive number"
                          f" got {max_drones!r}", file=sys.stderr)
                    sys.exit(1)
            except ValueError as e:
                raise ValueError(f"{e}")
            return (Zone(
                name=name,
                x=x,
                y=y,
                role=role,
                zone_type=zone_type,
                color=color,
                max_drones=max_drones))
        except Exception as e:
            print(f"Parsing error on line [{line!r}]: {e}", file=sys.stderr)
            sys.exit(1)

    def file_parser(self, path: str) -> Tuple[Dict[str, Zone], int]:
        """Parse a full map file into its zones and drone count.

        Args:
            path: Path to the map file to read.

        Returns:
            A tuple of (zones indexed by name, number of drones to route).
        """
        zones: Dict[str, Zone] = {}
        nb_drones: int = 0
        seen_connections: set[tuple[str, str]] = set()
        seen_coords: set[tuple[int, int]] = set()
        start_count: int = 0
        end_count: int = 0
        is_nb_drones: bool = False
        first_line: bool = True
        with open(path, "r") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                l_line: str = line.lower()
                if first_line and not l_line.startswith("nb_drones:"):
                    print(f"Error Line {line_num}: the first line must"
                          " define nb_drones", file=sys.stderr)
                    sys.exit(1)
                first_line = False
                try:
                    if l_line.startswith("nb_drones:"):
                        try:
                            if is_nb_drones:
                                print(f"Error line {line_num}:"
                                      " Duplicate"
                                      " nb_drones", file=sys.stderr)
                                sys.exit(1)
                            is_nb_drones = True
                            nb_drones = int(l_line.split(":", 1)[1].strip())
                            if nb_drones <= 0:
                                print(f"Error line {line_num}: number of"
                                      " drones must be ",
                                      "a positive number"
                                      f" got {nb_drones!r}", file=sys.stderr)
                                sys.exit(1)
                        except ValueError as e:
                            raise ValueError(f"{e}")
                    elif l_line.startswith(("start_hub:", "hub:", "end_hub:")):
                        role: str = l_line.split(":", 1)[0].strip()
                        zone: Zone | None = self.parse_zone_line(
                            line, role, line_num)
                        if zone:
                            if (zone.x, zone.y) not in seen_coords:
                                seen_coords.add((zone.x, zone.y))
                            else:
                                print(f"Error Line {line_num}: "
                                      "Got duplicate coordinates"
                                      f" ({zone.x},"
                                      f" {zone.y})", file=sys.stderr)
                                sys.exit(1)
                            if zone.name in zones:
                                print(f"Error Line {line_num}: "
                                      "Duplicate zone "
                                      f"name {zone.name!r}", file=sys.stderr)
                                sys.exit(1)
                            elif role == "start_hub":
                                start_count += 1
                            elif role == "end_hub":
                                end_count += 1
                            zones[zone.name] = zone
                    elif l_line.startswith("connection:"):
                        m_data: Dict[str, str] = {}
                        if "[" in l_line or "]" in l_line:
                            if "[" not in l_line or "]" not in l_line:
                                print(f"Error Line {line_num}:"
                                      " malformed metadata block",
                                      file=sys.stderr)
                                sys.exit(1)
                            start_idx: int = l_line.find("[")
                            end_idx: int = l_line.find("]")
                            if start_idx > end_idx:
                                print(f"Error line {line_num}: inverted"
                                      " metadata brackets  in"
                                      f" {l_line.strip()!r}", file=sys.stderr)
                                sys.exit(1)
                            if l_line[start_idx - 1] in (' ', '\t'):
                                m_data = self.parse_metadata(
                                    l_line[start_idx:end_idx + 1].strip(),
                                    line_num, l_line)
                            else:
                                print(f"Error line {line_num}: "
                                      "Ivalid metadata")
                                sys.exit(1)
                            l_line = (
                                line[
                                    :start_idx] + l_line[end_idx + 1:]).strip()
                        content: str = l_line.split(":", 1)[1].strip()
                        if "-" not in content:
                            print(
                                f"Error Line {line_num}:"
                                " Invalid connection format", file=sys.stderr)
                            sys.exit(1)
                        name_a, name_b = content.split("-", 1)
                        name_a, name_b = name_a.strip(), name_b.strip()
                        zone_a = zones.get(name_a)
                        zone_b = zones.get(name_b)
                        if zone_a and zone_b:
                            pair: tuple[str, str] = (
                                min(name_a, name_b), max(name_a, name_b))
                            if pair in seen_connections:
                                print(f"Error Line {line_num} in {path!r}: "
                                      f"duplicate connection {name_a}-"
                                      f"{name_b}", file=sys.stderr)
                                sys.exit(1)
                            seen_connections.add(pair)
                            try:
                                max_link_cap: int = int(
                                    m_data.get("max_link_capacity", 1))
                                if max_link_cap <= 0:
                                    print(f"Error line {line_num}: max link"
                                          " capacity must be",
                                          " a positive number got "
                                          f"{max_link_cap!r}", file=sys.stderr)
                                    sys.exit(1)
                            except ValueError as e:
                                raise ValueError(f"{e}")
                            conn: Connection = Connection(
                                zone_a, zone_b, max_link_cap)
                            zone_a.connections.append(conn)
                            zone_b.connections.append(conn)
                        else:
                            print(f"Error Line {line_num} in {path}: "
                                  "Zone not found"
                                  " for connection "
                                  f"{name_a}-{name_b}", file=sys.stderr)
                            sys.exit(1)
                    else:
                        print(f"Error line {line_num}:"
                              " Unrecognized line"
                              f" {l_line!r}", file=sys.stderr)
                        sys.exit(1)
                except Exception as e:
                    print(f"Error Line {line_num}: {e}", file=sys.stderr)
                    sys.exit(1)
            if start_count != 1 or end_count != 1:
                print(f"Error line {line_num}: Exactly one start_hub"
                      " and one end_hub required."
                      f" Found {start_count} start_hub,"
                      f" {end_count} end_hub.", file=sys.stderr)
                sys.exit(1)
            return zones, nb_drones
