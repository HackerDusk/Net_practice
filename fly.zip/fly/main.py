"""Main entry point for the Fly-in simulation."""
from models import (
    Zone,
    ZoneType,
    Drone
)
from algorithm import Path_finding
from parser import Parser
import argparse
import sys


class Simulator:
    """Parses CLI arguments, then plans and runs the full drone simulation."""

    @staticmethod
    def map_path_flag() -> argparse.Namespace:
        """Parse the command-line arguments (map file path, --visual flag)."""
        parser = argparse.ArgumentParser(
            description=("Design an efficient drone routing"
                         " system that navigates multiple drones"),
            usage=("uv run python3 -m src <path to a map file>"
                   " [--visual text or pygame]")
        )
        parser.add_argument(
            "map_path",
            help="The name of the file to process")
        parser.add_argument(
            "--visual",
            choices=["text", "pygame"],
            default="text",
            help="Display mode: plain-text turn log (default) or a pygame"
            " graphical simulation.")
        return parser.parse_args()

    def args(self) -> tuple[dict[str, Zone], int, str]:
        """Read the CLI arguments and parse the resulting map file.

        Returns:
            A tuple of (zones indexed by name, number of drones to route,
            the requested visual mode ('text' or 'pygame')).
        """
        parser: Parser = Parser()
        args: argparse.Namespace = self.map_path_flag()
        map_path: str = args.map_path
        zones, nb_drones = parser.file_parser(map_path)
        return ((zones, nb_drones, args.visual))

    @staticmethod
    def book_a_spot(
        path: list[tuple[Zone, int]],
        drone_id: int,
        agenda: dict[tuple[str, int], list[int]],
        conn_agenda: dict[tuple[str, str, int], list[int]]) -> tuple[
            dict[tuple[str, int],
                 list[int]], dict[tuple[str, str, int], list[int]]]:
        """Reserve every zone/connection slot a drone's path will occupy.

        Mutates `agenda` and `conn_agenda` in place so later calls to
        `path_finding` treat these slots as already taken.

        Args:
            path: The (zone, lap) path found for this drone.
            drone_id: The drone this path belongs to.
            agenda: Shared zone-occupancy calendar to update.
            conn_agenda: Shared connection-usage calendar to update.

        Returns:
            The same (agenda, conn_agenda) objects, already mutated in place.
        """
        conn_key: tuple[str, str, int] | None = None
        for i in range(len(path)):
            curr_zone, curr_lap = path[i]
            key: tuple[str, int] = (curr_zone.name, curr_lap)
            if key not in agenda:
                agenda[key] = []
            agenda[key].append(drone_id)
            if i > 0:
                prev_zone, prev_lap = path[i - 1]
                for t in range(prev_lap + 1, curr_lap):
                    t_key = (curr_zone.name, t)
                    if t_key not in agenda:
                        agenda[t_key] = []
                    agenda[t_key].append(drone_id)
                if prev_zone.name != curr_zone.name:
                    zone1, zone2 = sorted([
                        prev_zone.name, curr_zone.name])
                    conn_key = (zone1, zone2, prev_lap)
                    if conn_key not in conn_agenda:
                        conn_agenda[conn_key] = []
                    conn_agenda[conn_key].append(drone_id)

        return (agenda, conn_agenda)

    def fly_in(
        self,
        zones: dict[str, Zone],
        nb_drones: int,
            visual: str = "text") -> None:
        """Route every drone from start to end and report the simulation.

        Routes drones one at a time (first-come-first-served), booking each
        drone's path before searching for the next one, then expands every
        drone's path into a full tick-by-tick timeline and either shows the
        pygame visualization or prints the turn-by-turn movement log.

        Args:
            zones: All zones on the map, indexed by name.
            nb_drones: Number of drones to route from start to end.
            visual: "text" (default) for the plain turn-by-turn log, or
                "pygame" to open the graphical simulation window instead.
        """
        drones: list[Drone] = []
        path_finding: Path_finding = Path_finding()
        agenda: dict[tuple[str, int], list[int]] = {}
        conn_agenda: dict[tuple[str, str, int], list[int]] = {}
        for drone_id in range(1, nb_drones + 1):
            path: list[tuple[Zone, int]] | None = path_finding.path_finding(
                zones, agenda, conn_agenda)
            if path is None:
                print("Error: Unable to find a path "
                      f"for drone {drone_id}!", file=sys.stderr)
                sys.exit(1)
            agenda, conn_agenda = self.book_a_spot(
                path, drone_id, agenda, conn_agenda)
            full_timeline_path: list[Zone] = []
            for i in range(len(path)):
                zone, lap = path[i]
                if i == 0:
                    full_timeline_path.append(zone)
                    continue
                prev_zone, _ = path[i - 1]
                while len(full_timeline_path) < lap:
                    if (
                        zone.zone_type == ZoneType.RESTRICTED and len(
                            full_timeline_path) == lap - 1):
                        conn_name = f"{prev_zone.name}-{zone.name}"
                        conn_zone = Zone(conn_name, -1, -1, "connection")
                        full_timeline_path.append(conn_zone)
                    else:
                        full_timeline_path.append(prev_zone)
                full_timeline_path.append(zone)
            drones.append(Drone(drone_id, full_timeline_path))
        max_len = max(len(d.path_to_follow) for d in drones)

        if visual == "pygame":
            from visual_pygame import VisualPygame
            visual_pygame: VisualPygame = VisualPygame()
            visual_pygame.run_pygame_visual(zones, drones, max_len)
            return

        total_turns = 0
        for global_lap in range(1, max_len):
            moves = []
            for d in drones:
                if global_lap < len(d.path_to_follow):
                    curr_zone = d.path_to_follow[global_lap]
                    prev_zone = d.path_to_follow[global_lap - 1]
                    if curr_zone.name != prev_zone.name:
                        moves.append(f"D{d.drone_id}-{curr_zone.name}")
            total_turns = global_lap
            if moves:
                print(f"Total turns: {total_turns}", file=sys.stderr)
                print(" ".join(moves))


if __name__ == "__main__":
    try:
        simulator = Simulator()
        zones, nb_drones, visual = simulator.args()
        simulator.fly_in(zones, nb_drones, visual)
    except KeyboardInterrupt as e:
        print(e, file=sys.stderr)
    except Exception as e:
        print(e, file=sys.stderr)
        sys.exit(1)
