"""Pygame visualisation for Fly-in -- "dark node" styled graphical sim.

=====================================================================
INSTALLATION
=====================================================================
pygame is declared in pyproject.toml, so `make install` (or
`uv sync`) already pulls it in.

=====================================================================
ZONE RENDERING
=====================================================================
No external image asset is used: every zone is drawn directly as a
filled octagon, no border. The fill colour comes straight from the
zone's own `color` metadata (any name pygame.Color() understands,
e.g. "green", "red", "blue" ...); a zone with no `color` set, or an
unrecognised colour name, falls back to a neutral grey instead of
raising an error, matching the "handle exceptions gracefully" rule
from the subject (III.1) even for the visual part. There is no
background image and no drone sprite: the background is a small
gradient drawn in code, and each drone is shown as a compact "D<id>"
tag that glides between zones.

=====================================================================
WINDOW / LAYOUT
=====================================================================
The window is resizable and opens close to the size of your screen.
Resizing it live recomputes the whole layout (scale, node size,
background) so the map keeps filling the available space. The scale
also auto-grows past a simple "fit the window" size whenever needed
so that no two zone labels can ever overlap or collide, regardless
of how long the zone names are.

=====================================================================
KEYBOARD & MOUSE CONTROLS
=====================================================================
    (the simulation opens PAUSED on turn 0)
    SPACE       : pause / resume the simulation
    RIGHT ARROW : step forward one turn (pauses)
    LEFT ARROW  : step backward one turn (pauses)
    R           : replay -- restart the simulation from turn 0
    ESCAPE      : close the window
    CLICK-DRAG  : pan camera across the map

=====================================================================
HOW TO CALL THIS
=====================================================================
This module isn't meant to run on its own. From fly_in()
(main.py), once `drones: list[Drone]` and `max_len: int` have
been computed, call:

    from visual_pygame import VisualPygame
    if visual == "pygame":
        VisualPygame().run_pygame_visual(zones, drones, max_len)
"""

from __future__ import annotations

import math
import sys
import pygame
from typing import Optional
from models import Drone, Zone

MIN_WINDOW_SIZE = (640, 480)
DESKTOP_MARGIN = (80, 120)
TOP_BAR_HEIGHT = 70
SIDE_PADDING = 90
FIT_SCALE = 100.0
MIN_SCALE = 24.0
MAX_SCALE = 320.0
SCALE_STEP = 1.12
BASE_NODE_SIZE = 56
LABEL_GAP = 6
LABEL_PADDING = 10
FPS = 60
TURN_DELAY_MS = 650

DEFAULT_ZONE_COLOR: tuple[int, int, int] = (130, 130, 140)
DARK_COLOR_THRESHOLD = 45
DARK_COLOR_BORDER: tuple[int, int, int] = (190, 198, 215)

DRONE_LABEL_COLOR = (235, 240, 250)
DRONE_LABEL_BG = (14, 17, 24)
DRONE_LABEL_BORDER = (95, 105, 125)
ZONE_LABEL_COLOR = (220, 230, 240)

BG_TOP_COLOR = (10, 11, 18)
BG_BOTTOM_COLOR = (4, 5, 9)
SEGMENTS: dict[str, str] = {
    "0": "abcdef", "1": "bc", "2": "abged", "3": "abgcd",
    "4": "fgbc", "5": "afgcd", "6": "afgedc", "7": "abc",
    "8": "abcdefg", "9": "abcfgd",
}


class VisualPygame():
    """Pygame visualisation for Fly-in -- "dark node" styled graphical sim."""

    _warned_colors: set[str] = set()

    @staticmethod
    def _octagon_points(
        cx: int, cy: int, radius: int
    ) -> list[tuple[int, int]]:
        """Return the 8 vertices of a regular octagon centred on (cx, cy).

        Offset by 22.5 degrees so the octagon has flat top/bottom/side
        edges (the familiar "stop sign" orientation) instead of a
        vertex pointing straight up.
        """
        return [
            (
                int(cx + radius * math.cos(math.radians(22.5 + i * 45))),
                int(cy + radius * math.sin(math.radians(22.5 + i * 45))),
            )
            for i in range(8)
        ]

    @staticmethod
    def _resolve_zone_color(color_name: str) -> tuple[int, int, int]:
        """Turn a zone's `color` metadata into an RGB tuple.

        Falls back to a neutral grey when no color was given in the
        map file, or when the given name isn't one pygame recognises
        -- this never raises, matching the subject's "handle
        exceptions gracefully" rule (III.1) for the visual layer too.
        """
        if color_name == "none":
            return DEFAULT_ZONE_COLOR
        try:
            c = pygame.Color(color_name)
            return (c.r, c.g, c.b)
        except ValueError:
            if color_name not in VisualPygame._warned_colors:
                VisualPygame._warned_colors.add(color_name)
                print(f"[visual] unrecognised color '{color_name}'"
                      " (using grey)", file=sys.stderr)
            return DEFAULT_ZONE_COLOR

    @staticmethod
    def _luminance(color: tuple[int, int, int]) -> float:
        """Return the perceived brightness of an RGB colour (0-255)."""
        r, g, b = color
        return 0.2126 * r + 0.7152 * g + 0.0722 * b

    @staticmethod
    def _lerp_color(
        start: tuple[int, int, int],
        end: tuple[int, int, int],
        t: float,
    ) -> tuple[int, int, int]:
        """Interpolate linearly between two RGB colours."""
        return (
            int(start[0] + (end[0] - start[0]) * t),
            int(start[1] + (end[1] - start[1]) * t),
            int(start[2] + (end[2] - start[2]) * t),
        )

    def build_background_surface(
        self,
        window_w: int, window_h: int
    ) -> pygame.Surface:
        """Pre-render a dark vertical gradient the size of the window.

        Cheap replacement for the old starfield PNG: no asset to load,
        keeps the same "dark space" feel, and is always pixel-perfect for
        the current (resizable) window size.
        """
        surface = pygame.Surface((window_w, window_h))
        height = max(window_h, 1)
        for y in range(height):
            color = self._lerp_color(BG_TOP_COLOR, BG_BOTTOM_COLOR, y / height)
            pygame.draw.line(surface, color, (0, y), (window_w, y))
        return surface

    @staticmethod
    def draw_seven_seg_digit(
        screen: pygame.Surface,
        x: int, y: int, digit: str,
        color: tuple[int, int, int] = (60, 170, 255),
            w: int = 16, h: int = 24, thick: int = 5) -> None:
        """Draw a single digit as an LCD-style display.

        With unlit segments in a very dim grey so the ghost of a full '8' stays
        visible behind it, like on a real digital display.
        """
        on = SEGMENTS.get(digit, "")
        dim = tuple(max(c // 6, 12) for c in color)
        seg_rects = {
            "a": (x, y, w, thick),
            "b": (x + w - thick, y, thick, h),
            "c": (x + w - thick, y + h, thick, h),
            "d": (x, y + 2 * h - thick, w, thick),
            "e": (x, y + h, thick, h),
            "f": (x, y, thick, h),
            "g": (x, y + h - thick // 2, w, thick),
        }
        for seg, rect in seg_rects.items():
            pygame.draw.rect(
                screen, color if seg in on else dim, rect, border_radius=2)

    def draw_seven_seg_number(
        self,
        screen: pygame.Surface, x: int, y: int, number: str,
        color: tuple[int, int, int] = (60, 170, 255)
    ) -> None:
        """Draw a sequence of digits (e.g. '07') side by side."""
        cursor_x = x
        for ch in number:
            self.draw_seven_seg_digit(screen, cursor_x, y, ch, color)
            cursor_x += 22

    @staticmethod
    def node_size_for_scale(scale: float) -> int:
        """Compute the node tile size in pixels for a given scale.

        Clamped to a comfortable range.
        """
        return int(max(28, min(BASE_NODE_SIZE, scale * 0.6)))

    @staticmethod
    def to_pixel(
        zx: float,
        zy: float,
        scale: float,
        offset_x: float,
            offset_y: float) -> tuple[int, int]:
        """Convert a (possibly fractional, mid-animation).

        Map coordinate into an on-screen pixel position
        """
        return (
            int(round(offset_x + zx * scale)),
            int(round(offset_y + zy * scale)),
        )

    def _footprints_overlap(
        self,
        zones: dict[str, Zone],
        label_sizes: dict[str, tuple[int, int]],
        scale: float,
        window_w: int,
        window_h: int,
        min_x: int, min_y: int,
        span_x: int, span_y: int,
    ) -> bool:
        """Check whether any two zone "footprints".

        (tile + label, withpadding) would overlap on screen at the given scale.
        """
        map_w = span_x * scale
        map_h = span_y * scale
        offset_x = (window_w - map_w) / 2 - min_x * scale
        drawable_h = window_h - TOP_BAR_HEIGHT
        offset_y = TOP_BAR_HEIGHT + (drawable_h - map_h) / 2 - min_y * scale
        node_size = self.node_size_for_scale(scale)

        boxes: list[tuple[float, float, float, float]] = []
        for zone in zones.values():
            px, py = self.to_pixel(zone.x, zone.y, scale, offset_x, offset_y)
            label_w, label_h = label_sizes[zone.name]
            half_w = max(node_size, label_w) / 2 + LABEL_PADDING
            top = py - node_size / 2 - LABEL_PADDING
            bottom = (
                py + node_size / 2 + LABEL_GAP + label_h + LABEL_PADDING)
            boxes.append((px - half_w, top, px + half_w, bottom))

        for i in range(len(boxes)):
            left_a, top_a, right_a, bottom_a = boxes[i]
            for j in range(i + 1, len(boxes)):
                left_b, top_b, right_b, bottom_b = boxes[j]
                if (
                    left_a < right_b and left_b < right_a and (
                        top_a) < bottom_b and top_b < bottom_a):
                    return True
        return False

    def compute_layout(
        self,
        zones: dict[str, Zone],
        font: pygame.font.Font,
        window_w: int,
        window_h: int,
    ) -> tuple[float, float, float, int]:
        """Work out the scale, offsets and node size for the given window size.

        Starts from a "fit the window" scale, then grows it (never
        shrinks it) until every zone label has enough room, so labels
        never crush into each other no matter how long the zone names
        are -- the map may then extend a little past the window instead.

        Returns:
            (scale, offset_x, offset_y, node_size).
        """
        xs = [zone.x for zone in zones.values()]
        ys = [zone.y for zone in zones.values()]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        span_x = max(max_x - min_x, 1)
        span_y = max(max_y - min_y, 1)

        avail_w = max(window_w - 2 * SIDE_PADDING, 1)
        avail_h = max(window_h - TOP_BAR_HEIGHT - 2 * SIDE_PADDING, 1)

        scale = min(FIT_SCALE, avail_w / span_x, avail_h / span_y)
        scale = max(scale, MIN_SCALE)

        label_sizes = {
            zone.name: font.size(zone.name) for zone in zones.values()}

        while scale < MAX_SCALE and self._footprints_overlap(
                zones, label_sizes, scale, window_w, window_h,
                min_x, min_y, span_x, span_y):
            scale *= SCALE_STEP
        scale = min(scale, MAX_SCALE)

        map_w = span_x * scale
        map_h = span_y * scale
        offset_x = (window_w - map_w) / 2 - min_x * scale
        drawable_h = window_h - TOP_BAR_HEIGHT
        offset_y = TOP_BAR_HEIGHT + (drawable_h - map_h) / 2 - min_y * scale

        return scale, offset_x, offset_y, self.node_size_for_scale(scale)

    @staticmethod
    def get_desktop_size() -> tuple[int, int]:
        """Return the current desktop resolution, or a safe fallback.

        Return a safe fallback if it can't be detected.
        """
        try:
            info = pygame.display.Info()
            if info.current_w > 0 and info.current_h > 0:
                return info.current_w, info.current_h
        except pygame.error:
            pass
        return 1280, 800

    @staticmethod
    def initial_window_size(desktop_w: int, desktop_h: int) -> tuple[int, int]:
        """Pick a starting window size that fills most of the screen.

        Leaving a little room for OS chrome (taskbar, dock, title bar).
        """
        width = max(MIN_WINDOW_SIZE[0], desktop_w - DESKTOP_MARGIN[0])
        height = max(MIN_WINDOW_SIZE[1], desktop_h - DESKTOP_MARGIN[1])
        return width, height

    def draw_map(
        self,
        screen: pygame.Surface,
        zones: dict[str, Zone],
        font: pygame.font.Font,
        scale: float,
        offset_x: float,
        offset_y: float,
            node_size: int, ) -> None:
        """Draw every connection once (regardless of direction).

        Then every zone tile with its label, centred on their map coordinates.
        """
        drawn: set[tuple[str, str]] = set()
        for zone in zones.values():
            pos_a = self.to_pixel(zone.x, zone.y, scale, offset_x, offset_y)
            for other in zone.get_neighbors():
                key = key = (
                    (zone.name, other.name)
                    if zone.name < other.name
                    else (other.name, zone.name)
                )
                if key in drawn:
                    continue
                drawn.add(key)
                pos_b = self.to_pixel(
                    other.x, other.y, scale, offset_x, offset_y)
                pygame.draw.line(screen, (55, 70, 95), pos_a, pos_b, 2)

        for zone in zones.values():
            px, py = self.to_pixel(zone.x, zone.y, scale, offset_x, offset_y)
            fill = self._resolve_zone_color(zone.color)
            points = self._octagon_points(px, py, node_size // 2)
            pygame.draw.polygon(screen, fill, points)
            if self._luminance(fill) < DARK_COLOR_THRESHOLD:
                pygame.draw.polygon(
                    screen, DARK_COLOR_BORDER, points, width=2)

            label = font.render(zone.name, True, ZONE_LABEL_COLOR)
            screen.blit(
                label,
                (px - label.get_width() // 2, py + node_size // 2 + LABEL_GAP))

    @staticmethod
    def build_display_positions(drone: Drone) -> list[tuple[float, float]]:
        """Map each step of a drone's timeline to a real (x, y) map.

        Coordinate, interpolating the position of the virtual "in flight"
        markers (used while crossing a connection toward a restricted
        zone, whose coordinates are (-1, -1)).
        """
        path = drone.path_to_follow
        raw: list[Optional[tuple[float, float]]] = [
            None if step.role == "connection" else (
                float(step.x), float(step.y))
            for step in path
        ]

        resolved: list[tuple[float, float]] = []
        for i, pos in enumerate(raw):
            if pos is not None:
                resolved.append(pos)
                continue
            prev_i = i - 1
            while raw[prev_i] is None:
                prev_i -= 1
            next_i = i + 1
            while raw[next_i] is None:
                next_i += 1
            prev_pos = raw[prev_i]
            next_pos = raw[next_i]
            assert prev_pos is not None and next_pos is not None
            frac = (i - prev_i) / (next_i - prev_i)
            resolved.append((
                prev_pos[0] + (next_pos[0] - prev_pos[0]) * frac,
                prev_pos[1] + (next_pos[1] - prev_pos[1]) * frac,
            ))
        return resolved

    def draw_drones(
        self,
        screen: pygame.Surface,
        drones: list[Drone],
        display_positions: dict[int, list[tuple[float, float]]],
        global_time: int,
        progress: float,
        scale: float,
        offset_x: float,
        offset_y: float,
        font: pygame.font.Font,
    ) -> None:
        """Show every still-active drone as a "D<id>" tag centred on the zone.

        `progress` (0 to 1) glides the tag smoothly
        toward the next zone instead of jumping instantly, removing the
        stop-motion feel.
        """
        active: list[tuple[Drone, int, int]] = []
        for drone in drones:
            positions = display_positions[drone.drone_id]
            if global_time >= len(positions):
                continue

            cur_x, cur_y = positions[global_time]
            if global_time + 1 < len(positions):
                nxt_x, nxt_y = positions[global_time + 1]
                cur_x += (nxt_x - cur_x) * progress
                cur_y += (nxt_y - cur_y) * progress

            px, py = self.to_pixel(cur_x, cur_y, scale, offset_x, offset_y)
            active.append((drone, px, py))

        groups: dict[tuple[int, int], list[Drone]] = {}
        for drone, px, py in active:
            groups.setdefault((px, py), []).append(drone)

        for (px, py), group in groups.items():
            count = len(group)
            for i, drone in enumerate(group):
                label_y = int(py + (i - (count - 1) / 2) * 16)
                text = font.render(
                    f"D{drone.drone_id}", True, DRONE_LABEL_COLOR)
                rect = text.get_rect(center=(px, label_y))
                bg_rect = rect.inflate(8, 4)
                pygame.draw.rect(
                    screen, DRONE_LABEL_BG, bg_rect, border_radius=4)
                pygame.draw.rect(
                    screen, DRONE_LABEL_BORDER, bg_rect, width=1,
                    border_radius=4)
                screen.blit(text, rect)

    def draw_top_bar(
        self,
        screen: pygame.Surface,
        global_time: int,
        total_turns: int,
        paused: bool,
        window_w: int,
        font: pygame.font.Font,
    ) -> None:
        """Draw the top banner.

        current/total turn, paused/playing state,
        and a reminder of the keyboard and mouse shortcuts.
        """
        pygame.draw.rect(screen, (10, 12, 18), (
            0, 0, window_w, TOP_BAR_HEIGHT))
        pygame.draw.line(
            screen, (40, 45, 60), (0, TOP_BAR_HEIGHT), (
                window_w, TOP_BAR_HEIGHT))

        self.draw_seven_seg_number(screen, 20, 10, f"{global_time:02d}")
        total_label = font.render(f"/ {total_turns:02d}", True, (
            150, 170, 200))
        screen.blit(total_label, (86, 28))

        status = "PAUSED" if paused else "PLAYING"
        status_color = (255, 190, 90) if paused else (110, 230, 150)
        status_label = font.render(status, True, status_color)
        screen.blit(status_label, (185, 28))

        help_label = font.render(
            "SPACE: pause | ARROWS: step | R: replay "
            "| CLICK & DRAG: move map | ESC: quit",
            True, (140, 150, 165))
        screen.blit(help_label, (window_w - help_label.get_width() - 20, 28))

    def run_pygame_visual(
        self,
        zones: dict[str, Zone],
        drones: list[Drone],
            max_len: int) -> None:
        """Open the pygame window and play the simulation turn by turn.

        Controls:
            SPACE       : pause / resume
            RIGHT ARROW : step forward one turn (pauses)
            LEFT ARROW  : step backward one turn (pauses)
            R           : replay -- restart the simulation from turn 0
            DRAG MOUSE  : pan camera across the map
            ESCAPE      : close the window

        The window is resizable: the whole layout (scale, node size,
        background) recomputes on every resize, so the map keeps filling
        the available window space instead of staying a fixed size.
        """
        pygame.init()
        try:
            font = pygame.font.SysFont("consolas", 15)

            desktop_w, desktop_h = self.get_desktop_size()
            window_w, window_h = self.initial_window_size(desktop_w, desktop_h)
            screen = pygame.display.set_mode(
                (window_w, window_h), pygame.RESIZABLE)
            pygame.display.set_caption("Fly-in - simulation")
            clock = pygame.time.Clock()

            scale, offset_x, offset_y, node_size = self.compute_layout(
                zones, font, window_w, window_h)
            background = self.build_background_surface(window_w, window_h)

            display_positions = {
                drone.drone_id: self.build_display_positions(drone)
                for drone in drones
            }

            global_time = 0
            paused = True
            last_tick = pygame.time.get_ticks()
            running = True

            pan_x = 0.0
            pan_y = 0.0
            dragging = False

            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    elif event.type == pygame.VIDEORESIZE:
                        window_w = max(MIN_WINDOW_SIZE[0], event.w)
                        window_h = max(MIN_WINDOW_SIZE[1], event.h)
                        screen = pygame.display.set_mode(
                            (window_w, window_h), pygame.RESIZABLE)
                        (
                            scale,
                            offset_x,
                            offset_y,
                            node_size) = self.compute_layout(
                            zones, font, window_w, window_h)
                        background = self.build_background_surface(
                            window_w, window_h)
                        pan_x = 0.0
                        pan_y = 0.0
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button == 1:
                            dragging = True
                    elif event.type == pygame.MOUSEBUTTONUP:
                        if event.button == 1:
                            dragging = False
                    elif event.type == pygame.MOUSEMOTION:
                        if dragging:
                            dx, dy = event.rel
                            pan_x += dx
                            pan_y += dy
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False
                        elif event.key == pygame.K_SPACE:
                            paused = not paused
                            last_tick = pygame.time.get_ticks()
                        elif event.key == pygame.K_RIGHT:
                            paused = True
                            global_time = min(global_time + 1, max_len - 1)
                            last_tick = pygame.time.get_ticks()
                        elif event.key == pygame.K_LEFT:
                            paused = True
                            global_time = max(global_time - 1, 0)
                            last_tick = pygame.time.get_ticks()
                        elif event.key == pygame.K_r:
                            global_time = 0
                            paused = False
                            pan_x = 0.0
                            pan_y = 0.0
                            last_tick = pygame.time.get_ticks()

                now = pygame.time.get_ticks()
                progress = 0.0
                if not paused and global_time < max_len - 1:
                    elapsed = now - last_tick
                    if elapsed >= TURN_DELAY_MS:
                        global_time += 1
                        last_tick = now
                        elapsed = 0
                    progress = min(1.0, elapsed / TURN_DELAY_MS)

                screen.blit(background, (0, 0))
                self.draw_map(
                    screen, zones, font, scale,
                    offset_x + pan_x, offset_y + pan_y,
                    node_size)
                self.draw_drones(
                    screen, drones, display_positions, global_time, progress,
                    scale, offset_x + pan_x, offset_y + pan_y, font)
                self.draw_top_bar(
                    screen, global_time, max_len - 1, paused, window_w, font)

                pygame.display.flip()
                clock.tick(FPS)
        finally:
            pygame.quit()
